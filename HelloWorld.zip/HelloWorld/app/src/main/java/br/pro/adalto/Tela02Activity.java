package br.pro.adalto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Tela02Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela02);
    }
}